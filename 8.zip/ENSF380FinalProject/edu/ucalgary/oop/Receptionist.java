package edu.ucalgary.oop;
/**@author Noor 
* This class is for creating receptionists 
*/
public class Receptionist extends Employee{

    public Receptionist(int userStaffId, String userName) {
        super(userStaffId, userName);
    }

}
